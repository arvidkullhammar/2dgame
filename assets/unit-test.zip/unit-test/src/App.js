import logo from "./logo.svg";
import "./App.css";
import { Header, Counter } from "./components";
function App() {
  return (
    <div className="App">
      <Header />
      <Counter />
    </div>
  );
}

export default App;
