export const Header = () => {
  return <h1 role="heading">Welcome to our counter app</h1>;
};
