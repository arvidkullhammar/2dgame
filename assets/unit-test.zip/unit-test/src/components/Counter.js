import { useState } from "react";

export function Counter() {
  const [counter, setCounter] = useState(0);

  const increaseCount = () => {
    setCounter((counter) => counter + 1);
  };
  const decreaseCount = () => {
    setCounter((counter) => counter - 1);
  };

  return (
    <div>
      <p role="dialog">You have clicked {counter} times.</p>
      <div>
        <button onClick={increaseCount}>Increase count</button>
        <button onClick={decreaseCount}>Decrease count</button>
      </div>
    </div>
  );
}
