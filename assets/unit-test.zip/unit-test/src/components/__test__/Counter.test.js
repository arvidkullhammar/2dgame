import { render, fireEvent } from "@testing-library/react";
import { Counter } from "../Counter";

test("Counter should render", () => {
  render(<Counter />);
});

describe("<Counter />", () => {
  test("should say 1 when increase button is clicked", async () => {
    const { getByText, getByRole, findByText } = render(<Counter />);
    const paragraphTag = getByRole("dialog");
    const buttonToClick = getByText(/Increase/i);

    expect(paragraphTag).toHaveTextContent("You have clicked 0 times.");
    fireEvent.click(buttonToClick);
    await findByText("You have clicked 1 times.");
  });

  // Todo: implement test for click decrease here
});
